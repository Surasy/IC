package id3;

import java.util.ArrayList;
import java.util.Iterator;

public class Nodo {
	private String nombre;
	private ArrayList<Nodo> hijos;
	private ArrayList<String> aristas;
	
	public Nodo(String nombre) {
		this.nombre = nombre;
		this.hijos = new ArrayList<Nodo>();
		this.aristas = new ArrayList<String>();
	}
	
	public void addHijo(Nodo hijo, String nombreArista) {
		this.hijos.add(hijo);
		this.aristas.add(nombreArista);
	}

	




	//https://stackoverflow.com/questions/4965335/how-to-print-binary-tree-diagram
	public String toString() {
		StringBuilder buffer = new StringBuilder(50);
        print(buffer, "", "");
        return buffer.toString();
	}
	
	private void print(StringBuilder buffer, String prefix, String childrenPrefix) {
        buffer.append(prefix);
        buffer.append(this.nombre);
        buffer.append('\n');
        for (int i = 0; i < hijos.size(); i++) {
            Nodo next = hijos.get(i);
            if (i < hijos.size() - 1) {
                next.print(buffer, childrenPrefix + "├──[" + aristas.get(i) + "]─ ", childrenPrefix + "│               ");
				
            } else {
                next.print(buffer, childrenPrefix + "└──[" + aristas.get(i) + "]─ ", childrenPrefix + "                ");
            }
        }
    }
}
